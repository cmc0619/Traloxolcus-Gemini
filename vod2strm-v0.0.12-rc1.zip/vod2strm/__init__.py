from .plugin import Plugin

# Optional: module-level re-exports so either style works
name = Plugin.name
version = Plugin.version
description = Plugin.description
fields = Plugin.fields
actions = Plugin.actions
